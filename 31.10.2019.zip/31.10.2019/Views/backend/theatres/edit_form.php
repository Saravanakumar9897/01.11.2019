<!DOCTYPE html>
<html>
<head>
	<title>Editting form for Theatre admins</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../../../../../css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo asset('backend/css/style.css') ?>">
</head>
<body>
	<div class="container">
		<div class="jumbotron">
			<div class="row">
				<div class="col-md-12">
					<div class="card">
						<div class="card-header text-center">New Theatre registration form</div>
						<div class="card-body">
							<form class="form form-inline row" method="post">
								<div class="col-md-12 form-control">	
									<div class="form-group custom_row">
										<div class="col-md-6">
											<label for="theatrename">Theatre name:</label> 
										</div>
										<div class="col-md-6">
											<input type="text" name="theatrename" placeholder="Enter Theatre name" class="form-control" id="Theatrename">
										</div> 
									</div>
									<div class="form-group  custom_row">
										<div class="col-md-6">
											<label for="No_screen">Number of new Screen:</label> 
										</div>
										<div class="col-md-6">
											<input type="number" name="screen_number" placeholder="1" class="form-control" id="Screen_number">
										</div>
									</div>
									<div class="form-group  custom_row">
										<div class="col-md-6">
											<label for="No_screen">Name of Screen:</label> 
										</div>
										<div class="col-md-6">
											<input type="name" name="no_number" placeholder="Enter your Screen name" class="form-control" id="Name_screen">
										</div>
									</div>
									<div class="form-group  custom_row">
										<div class="col-md-6">
											<label for="No_show">Number of Shows:</label> 
										</div>
										<div class="col-md-6">
											<input type="checkbox" name="time1" class="form-control" id="Time1">  morning-show</input><br>
											<input type="checkbox" name="time1" class="form-control" id="Time1">  afternoon-show</input><br>
											<input type="checkbox" name="time1" class="form-control" id="Time1">  evening-show</input><br>
											<input type="checkbox" name="time1" class="form-control" id="Time1">  night-show</input>
										</div>
									</div>
									<div class="form-group  custom_row">
										<div class="col-md-6">
											<label for="Location">Location:</label> 
										</div>
										<div class="col-md-6">
											<input type="name" name="location" placeholder="city" class="form-control" id="location">
										</div>
									</div>
							
									<div class="form-group  custom_row">
										<div class="col-md-6">
											<label for="Comments">Comments:</label> 
										</div>
										<div class="col-md-6">
											<textarea cols="35" rows="4" placeholder="Comments:"></textarea>
										</div>
									</div><br>
									<div class="col-md-12 text-center">
										<a class="btn btn-primary">Submit Request</a>
										<?php echo str_repeat('&nbsp;', 15); ?>
										<a class="btn btn-danger">Go Home</a>
									</div><br>
								</div>
							</form>
						</div>
						<div class="card-footer text-left">copyrights @movie_ticket_booking pvt ltd..,</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
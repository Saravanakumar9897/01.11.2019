<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
<?php view('backend/partial/nav_bar.php') ?>
<?php view('backend/partial/side_bar.php') ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i>Theatres</h1>
            <p> Add Theatre</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo baseURL().'/admin'; ?>"><i class="fa fa-home fa-lg"></i></a></li>
            <li class="breadcrumb-item"><a href="#">theatre / add </a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <span class="pull-left">Add Theatre</span>
                    <a href="<?php echo baseURL().'/theatreDetails'; ?>" class="fa fa-list pull-right text-success" title="View All"></a>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo baseURL().'/newTheatreUpdate' ?>">
                        <div class="row">
                            <div class="col-md-2">
                                <label for="adminname">Admin name:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="adminName" placeholder="Enter Name Of Admin" required>
                            </div>
                            <div class="col-md-2">
                                <label for="adminemail">E-mail:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="adminEmail" placeholder="Enter the Email Address" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrephone">Phone No:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="phone" name="phoneNumber" placeholder="Enter Phone Number" required>
                            </div>
                            <div class="col-md-2">
                                <label for="aadharnumber">Aadhar Number:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="phone" name="aadharNumber" placeholder="XXXX XXXX XXXX XXXX" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrename">Theatre name:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="theatreName" placeholder="Enter Name Of Theatre" required>
                            </div>
                            <div class="col-md-2">
                                <label for="theatrephone">Total Screen:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="number" name="screenNumber" placeholder="Enter total screen" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrename">Enter Password:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="pass" name="password" placeholder="Enter Password" required>
                            </div>
                            <div class="col-md-2">
                                <label for="theatrephone">Re-enter Password:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="pass" name="confirmPassword" placeholder="Re-enter Password" required>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-2">
                                <label for="theatrelocation">Theatre Address:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="theatreLocation" placeholder="Enter the Address" required>
                            </div>
                            <div class="col-md-2">
                                <label for="comments">Comments:</label>
                            </div>
                            <div class="col-md-4">
                                <input class="form-control" type="text" name="comments" placeholder="Enter your comments" required>
                            </div>
                        </div><br><br>
                        <div class="row">
                            <div class="col-md-3">
                                
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-2">
                                <a  class="form-control btn-primary text-center" href="<?php echo baseURL().'/admin'; ?>">Go Home</a>
                            </div>
                            <div class="col-md-2">
                                <input class="form-control btn-primary" type="submit" value="Submit">
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-3">
                                
                            </div>
                        </div><br>
                    </form>
                </div>
                <div class="card-footer">
                    <div class="row"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php view('backend/partial/foot_links.php') ?>
</body>
</html>


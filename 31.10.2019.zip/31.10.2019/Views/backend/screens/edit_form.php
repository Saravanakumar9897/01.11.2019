<!DOCTYPE html>
<html lang="en">
<head>
    <?php view('backend/partial/head_links.php') ?>
</head>
<body class="app sidebar-mini">
<?php view('backend/partial/nav_bar.php') ?>
<?php view('backend/partial/side_bar.php') ?>
<?php $arr = import(); $screen = $arr[0]; $theatres = $arr[1]; ?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Screens</h1>
            <p>Edit Screen</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="#">screen / edit </a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <span class="pull-left">Edit Screen</span>
                    <a href="<?php echo baseURL().'/screenIndex'; ?>" class="fa fa-list pull-right text-success" title="View All"></a>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo baseURL().'/screenUpdate' ?>">
                        <input type="hidden" name="screenId" value="<?php echo $screen['screen_id'];?>">
                        <div class="row">
                            <div class="col-md-6">
                                <select class="form-control" name="screenTheatre" required>
                                    <?php foreach ($theatres as $theatre){ ?>
                                        <option value="<?php echo $theatre['theatre_id']?>" <?php  if($theatre['theatre_id'] == $screen['r_theatre_id']) { echo 'selected'; } ?>><?php echo $role['theatre_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" type="text" name="screenName" value="<?php echo $screen['screen_name']; ?>" placeholder="Enter Screen Name" required>
                            </div>
                        </div><hr>
                        <div class="row">
                            <div class="col-md-6">
                                <select class="form-control" name="screenStatus" required>
                                    <option disabled selected>Select Status</option>
                                    <option value="1" <?php echo $screen['screen_status']==1? 'selected':''; ?>>Active</option>
                                    <option value="0" <?php echo $screen['screen_status']==0? 'selected':''; ?>>Suspend</option>
                                </select>
                            </div>
                             <div class="col-md-6">
                                <input class="form-control btn btn-outline-primary" type="submit" value="Update This Screen" required>
                            </div>
                        </div><hr>                  
                       
                    </form>
                </div>
                <div class="card-footer">
                    <div class="row"></div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php view('backend/partial/foot_links.php') ?>
</body>
</html>

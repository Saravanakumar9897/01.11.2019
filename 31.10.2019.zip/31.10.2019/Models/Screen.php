<?php
namespace Models;

use Connection\DB;
use Throwable;

class Screen
{
    private $table = 't_screens';
    private $fields = ['screen_id','r_theatre_id','screen_name','screen_status'];

   
    public static function all(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_screens");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function insert($data){
        try{
            $sql = "INSERT INTO t_screens (r_theatre_id,screen_name,screen_status) 
                    VALUES (:r_theatre_id,:screen_name,:screen_status)";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([
                ':r_theatre_id'=>$data['screenTheatre'],
                ':screen_name'=>$data['screenName'],                
                ':screen_status'=>$data['screenStatus']
            ]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function select($screen_id){
        try{
            $stmt = DB::getConnection()->prepare(" 
              SELECT 
                  screens.r_theatre_id, 
                  screens.*,
                  theatres.* 
              FROM 
                  t_screens as screens
              INNER JOIN 
                  t_theatres as theatres
                  ON theatres.theatre_id = screens.r_theatre_id
              WHERE screen_id = :screen_id LIMIT 1"
            );
            $stmt->execute([':screen_id' => $screen_id]);
            return $stmt->fetch();
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function update($data){
        try{
            $sql = "UPDATE 
                        t_screens 
                    SET 
                        r_theatre_id =:r_theatre_id, 
                        screen_name =:screen_name,                        
                        screen_status =:screen_status
                    WHERE 
                        screen_id =:screen_id
                    ";
            $stmt= DB::getConnection()->prepare($sql);
             $stmt->execute([
                ':r_theatre_id'=>$data['screenTheatre'],
                ':screen_name'=>$data['screenName'],                
                ':screen_status'=>$data['screenStatus']
            ]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function delete($screen_id){
        try{
            $sql = 'DELETE FROM 
                        t_screens 
                    WHERE 
                        screen_id = :screen_id';
            $q = DB::getConnection()->prepare($sql);
            $q->execute([':screen_id' => $screen_id]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
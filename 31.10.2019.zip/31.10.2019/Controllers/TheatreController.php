<?php
namespace Controllers;

use Models\Theatre;
use Request\Request;
class TheatreController
{
    public function __construct()
    {
        auth('SuperAdminData');
    }

    public function theatreDetails(){
        $theatres = Theatre::all();
        export('backend/theatres/theatreDetails',$theatres);
    }

    public function newTheatreForm(){
        $theatres = Theatre::collections();
        export('backend/theatres/newrequest_form',$theatres);
    }

    public function newTheatreUpdate(Request $request){
        try {
        $formData = $request->getBody();
        Theatre::addAdmin($formData);
        $user_id = Theatre::adminSelect($formData);
        Theatre::addTheatre([$formData,$user_id]);
        $theatres = Theatre::all();
        export('backend/theatres/theatreDetails',$theatres);  
        } catch (Throwable $e) {
           dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile()); 
        }
    }

    public function collectionDetails(){
        $collections = Theatre::collections();
        export('backend/collections/collectionDetails',$collections);
    }

    public function newScreenForm(){
        $collections = Theatre::all();
        export('backend/theatres/create_theatre_form',$collections);
    }

    public function newTheatreRequest(Request $request){
       $formData = $request->getBody();
        Theatre::insert_request($formData);
        redirect('/theatreDetails');
    }

    public function theatreShow(Request $request){
        $formData = $request->getBody();
        $theatres = Theatre::select($formData['theatre_id']);
        export('backend/theatres/show',$theatres);
    }

    public function theatreEdit(Request $request){
        $formData = $request->getBody();
        $theatres = Theatre::select($formData['theatre_id']);
        export('backend/theatres/edit_Form',$theatres);
    }

    public function theatreUpdate(Request $request){
        $formData = $request->getBody();
        Theatre::update($formData);
        $theatres = Theatre::all();
        export('backend/theatres/theatreDetails',$theatres);
    }

    public function theatreDelete(Request $request){
        try {
            $formData = $request->getBody();
            Theatre::delete($formData['theatre_id']);
            $theatres = Theatre::all();
            export('backend/theatres/theatreDetails',$theatres);
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}

?>
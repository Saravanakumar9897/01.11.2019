<?php
/**
 * Created by PhpStorm.
 * User:Banupriya
 * Date: 24/10/19
 * Time: 1:03 AM
 */

namespace Controllers;


use Models\Seat;
use Request\Request;
use Throwable;

class SeatController
{
    public function __construct()
    {
        auth('SuperAdminData');
    }

    public function seatIndex(){
        try {
            $seats = Seat::all();
            export('backend/seats/view_all',$seats);
        }catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function seatForm(){
        try {
            export('backend/seats/create_form','');
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function seatStore(Request $request){
       try {
           $formData = $request->getBody();
           Seat::insert($formData);
           redirect('/seatIndex');
       } catch (Throwable $e) {
           dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    public function seatShow(Request $request){
        try {
            $formData = $request->getBody();
            $seat = Seat::select($formData['seat_id']);
            export('backend/seats/show',$seat);
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function seatEditForm(Request $request){
        try {
            $formData = $request->getBody();
            $seat = Seat::select($formData['seat_id']);
            export('backend/seats/edit_form',$seat);
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public function seatUpdate(Request $request){
       try {
           $formData = $request->getBody();
           Seat::update($formData);
           redirect('/seatIndex');
       } catch (Throwable $e) {
           dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
       }
    }

    public function SeatDelete(Request $request){
        try {
            $formData = $request->getBody();
            Seat::delete($formData['seat_id']);
            redirect('/seatIndex');
        } catch (Throwable $e) {
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}

?>
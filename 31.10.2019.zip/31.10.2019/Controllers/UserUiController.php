<?php

// Author:saravana
// Description: userinterface controllers

namespace Controllers;

use Request\Request;
use Models\Movie;

class UserUiController{

	public function chennaiMovies(){


		// view('chennaiMovies.php');
		try{

			$movies = Movie::all();
			export('chennaiMovies',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}


	}
	public function bigil()
	{
		#code....
		try{

			$movies = Movie::all();
			export('bigil',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('bigil.php');
	}
	public function kaithi()
	{
		#code....
		try{

			$movies = Movie::all();
			export('kaithi',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function selectShow()
	{
		#code....
		try{

			$movies = Movie::all();
			export('selectShow',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function seat(){
		view('seat.php');
	}

}